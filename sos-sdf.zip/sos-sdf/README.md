Realiser un site statique pour une association apportant une aide a des sans abris 
Mobile first
Responsive 
Outils : Bootstrap  / Github / VS code / Adobe xd
Minimun 2 pages : Une sur l'association elle meme, une autre portant sur des evenements
